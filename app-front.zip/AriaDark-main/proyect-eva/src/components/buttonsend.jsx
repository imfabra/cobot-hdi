import React from "react";
import "../stylesheets/buttonsend.css"
function Buttonsend({ textbutton }){
  return(
    <div className="container-buttonsend">
      {textbutton}
    </div>
  );
}


export default Buttonsend;