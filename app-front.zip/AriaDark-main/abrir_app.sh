#!/bin/bash

# Navega a la ruta de tu aplicación React
cd /home/aria/Documentos/Dev/cobot-hdi-feature-api-Asynchronism/app-front/proyect-eva

# Ejecuta npm start para iniciar la aplicación
npm start

